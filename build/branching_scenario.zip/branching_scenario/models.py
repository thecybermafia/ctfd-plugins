import hashlib
import json
from CTFd.models import Challenges, db


def public_node_id(challenge_id, node_id):
    """Opaque, stable id for a scenario node (CPQuest local fix: hides real node names like "win")."""
    from flask import current_app

    secret = str(current_app.config.get("SECRET_KEY") or "")
    digest = hashlib.sha256(f"{secret}|branching|{challenge_id}|{node_id}".encode("utf-8")).hexdigest()
    return "n" + digest[:12]


class BranchingScenarioChallenge(Challenges):
    __mapper_args__ = {"polymorphic_identity": "branching_scenario"}
    id = db.Column(
        db.Integer, db.ForeignKey("challenges.id", ondelete="CASCADE"), primary_key=True
    )
    nodes_json = db.Column(db.Text, default="{}")
    start_node_id = db.Column(db.String(64), default="start")
    winning_nodes = db.Column(db.String(256), default="win")
    allow_restart = db.Column(db.Boolean, default=True)
    show_feedback = db.Column(db.Boolean, default=True)
    explanation = db.Column(db.Text, default="")

    def __init__(self, *args, **kwargs):
        self.nodes_json = kwargs.pop("nodes_json", "{}")
        self.start_node_id = kwargs.pop("start_node_id", "start")
        self.winning_nodes = kwargs.pop("winning_nodes", "win")
        self.allow_restart = kwargs.pop("allow_restart", True)
        if isinstance(self.allow_restart, str):
            self.allow_restart = self.allow_restart.lower() in ("true", "1", "yes", "on")
        self.show_feedback = kwargs.pop("show_feedback", True)
        if isinstance(self.show_feedback, str):
            self.show_feedback = self.show_feedback.lower() in ("true", "1", "yes", "on")
        self.explanation = kwargs.pop("explanation", "")
        # CPQuest local fix: scenario_text / scenario_json are read-only properties (create() parses them)
        kwargs.pop("scenario_text", None)
        kwargs.pop("scenario_json", None)
        super(BranchingScenarioChallenge, self).__init__(**kwargs)

    @property
    def nodes_data(self):
        try:
            return json.loads(self.nodes_json or "{}")
        except Exception:
            return {}

    @property
    def public_start_id(self):
        return public_node_id(self.id, self.start_node_id or "start")

    @property
    def scenario_json(self):
        return self.nodes_json

    @property
    def scenario_text(self):
        try:
            nodes = json.loads(self.nodes_json or "{}")
            blocks = []
            for nid, nd in nodes.items():
                b = [f"[{nid}] {nd.get('title', '')}"]
                if nd.get("text"):
                    b.append(nd.get("text", ""))
                for opt in nd.get("options", []):
                    line = f"> {opt.get('text', '')} -> {opt.get('next_node', '')}"
                    if opt.get("consequence"):
                        line += f" | {opt.get('consequence', '')}"
                    b.append(line)
                blocks.append("\n".join(b))
            return "\n\n".join(blocks)
        except Exception:
            return ""

    # CPQuest local fix: the admin create/update forms post these display-only fields and
    # CTFd assigns every posted field onto the model. Without a setter that raised
    # AttributeError and the save failed; the plugin already parses the text itself.
    @scenario_json.setter
    def scenario_json(self, value):
        pass

    @scenario_text.setter
    def scenario_text(self, value):
        pass

