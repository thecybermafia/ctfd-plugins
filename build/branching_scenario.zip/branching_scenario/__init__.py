from flask import Blueprint, abort, jsonify, request
from CTFd.models import Solves, db
from CTFd.utils.decorators import during_ctf_time_only
from CTFd.utils.decorators.visibility import check_challenge_visibility
from CTFd.utils.user import get_current_team, get_current_user, is_admin
from CTFd.plugins import register_plugin_assets_directory
from CTFd.plugins.challenges import CHALLENGE_CLASSES
from CTFd.plugins.branching_scenario.challenge import BranchingScenarioChallengeType, build_public_step
from CTFd.plugins.branching_scenario.models import BranchingScenarioChallenge


# CPQuest local fix: server-driven scenario steps (see challenge.build_public_step)
branching_api = Blueprint("branching_scenario_api", __name__)


@branching_api.route("/api/v1/challenges/<int:challenge_id>/branching/step", methods=["POST"])
@check_challenge_visibility
@during_ctf_time_only
def branching_step(challenge_id):
    c = BranchingScenarioChallenge.query.filter_by(id=challenge_id).first_or_404()
    if not is_admin():
        if c.state == "hidden":
            abort(404)
        prereqs = (c.requirements or {}).get("prerequisites") or []
        if prereqs:
            user = get_current_user()
            team = get_current_team()
            if not user:
                abort(403)
            q = Solves.query.filter(Solves.challenge_id.in_(prereqs))
            q = q.filter(Solves.team_id == team.id) if team else q.filter(Solves.user_id == user.id)
            if len({s.challenge_id for s in q.all()}) < len(set(prereqs)):
                abort(403)
    data = request.get_json(silent=True) or {}
    path = data.get("path") or []
    if not isinstance(path, list) or len(path) > 200:
        return jsonify({"success": False, "message": "Invalid path."}), 400
    payload, error = build_public_step(c, [str(p) for p in path])
    if error:
        return jsonify({"success": False, "message": error}), 400
    return jsonify({"success": True, "data": payload})


def load(app):
    with app.app_context():
        BranchingScenarioChallenge.__table__.create(bind=db.engine, checkfirst=True)

    CHALLENGE_CLASSES["branching_scenario"] = BranchingScenarioChallengeType
    app.register_blueprint(branching_api)

    register_plugin_assets_directory(
        app, base_path="/plugins/branching_scenario/assets/"
    )
