(function() {
CTFd._internal.challenge.data = undefined;
CTFd._internal.challenge.renderer = null;
CTFd._internal.challenge.preRender = function() {};
CTFd._internal.challenge.render = null;

// CPQuest local fix: server-driven scenario. The page no longer contains the decision graph,
// node ids or winning endings; each step is fetched from
// /api/v1/challenges/<id>/branching/step and the outcome is only revealed after grading.
function initScenario() {
  const chalIdEl = document.getElementById("challenge-id");
  const container = document.querySelector(".branching-scenario-container");
  if (!chalIdEl || !container) return false;
  // init runs several times per modal (postRender, event, retry timer); set up each modal once
  if (container.dataset.scenarioInit === "1") return true;
  container.dataset.scenarioInit = "1";

  const challengeId = chalIdEl.value;
  const configJsonEl = document.getElementById("branching-scenario-config-json");
  const chalInput = document.getElementById("challenge-input");
  const restartBtn = document.getElementById("scenario-restart-btn");
  const statusBadge = document.getElementById("scenario-status-badge");
  const titleEl = document.getElementById("scenario-node-title");
  const badgeEl = document.getElementById("scenario-node-badge");
  const textEl = document.getElementById("scenario-node-text");
  const consequenceBox = document.getElementById("scenario-consequence-box");
  const consequenceText = document.getElementById("scenario-consequence-text");
  const mediaContainer = document.getElementById("scenario-media-container");
  const mediaElement = document.getElementById("scenario-media-element");
  const transcriptBox = document.getElementById("scenario-transcript-box");
  const transcriptText = document.getElementById("scenario-transcript-text");
  const actionsSection = document.getElementById("scenario-actions-section");
  const optionsContainer = document.getElementById("scenario-options-container");
  const outcomeCard = document.getElementById("scenario-outcome-card");
  const outcomeTitle = document.getElementById("scenario-outcome-title");
  const outcomeDesc = document.getElementById("scenario-outcome-desc");
  const outcomeActions = document.getElementById("scenario-outcome-actions");
  const submitBtn = document.getElementById("challenge-submit");

  let config = {};
  if (configJsonEl && configJsonEl.textContent) {
    try {
      config = JSON.parse(configJsonEl.textContent);
    } catch (e) {
      console.error("Failed to parse branching_scenario config JSON:", e);
    }
  }

  const startId = config.start_public_id;
  const allowRestart = config.allow_restart !== false;
  const isSolved = Boolean(config.is_solved);
  const storageKey = `ctfd_scenario_path_${challengeId}`;
  const csrf = (window.init && window.init.csrfNonce) || (window.CTFd && window.CTFd.config && window.CTFd.config.csrfNonce) || "";

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str || "";
    return div.innerHTML;
  }

  let historyPath = [startId];
  let busy = false;

  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    if (saved && Array.isArray(saved.path) && saved.path.length && saved.path[0] === startId) {
      historyPath = saved.path;
    }
  } catch (e) {}

  function saveState() {
    try {
      localStorage.setItem(storageKey, JSON.stringify({ path: historyPath }));
    } catch (e) {}
    if (chalInput) {
      chalInput.value = JSON.stringify({
        node_id: historyPath[historyPath.length - 1],
        path: historyPath
      });
      chalInput.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }

  async function loadStep(path) {
    const res = await fetch(`/api/v1/challenges/${challengeId}/branching/step`, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "CSRF-Token": csrf },
      body: JSON.stringify({ path })
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok || !body.success) {
      throw new Error(body.message || `Scenario step failed (${res.status})`);
    }
    return body.data;
  }

  async function go(path) {
    if (busy) return;
    busy = true;
    try {
      const node = await loadStep(path);
      historyPath = path;
      saveState();
      renderNode(node);
    } catch (e) {
      if (path.length > 1) {
        busy = false;
        return go([startId]);
      }
      if (titleEl) titleEl.textContent = "Scenario unavailable";
      if (textEl) textEl.textContent = e.message;
    } finally {
      busy = false;
    }
  }

  function restartScenario() {
    go([startId]);
  }

  if (restartBtn) {
    restartBtn.addEventListener("click", restartScenario);
  }

  function setOutcome(kind, node) {
    // kind: "pending" (ending reached, not yet graded), "correct", "incorrect"
    if (!outcomeCard) return;
    outcomeCard.style.display = "block";
    outcomeCard.style.boxShadow = "";
    const desc = (node && node.text) || "";
    if (kind === "correct") {
      if (statusBadge) { statusBadge.textContent = "RESOLVED"; statusBadge.className = "badge bg-success font-monospace"; }
      outcomeCard.className = "p-3 rounded border border-success text-center font-monospace mt-3 tactical-card";
      outcomeCard.style.boxShadow = "0 0 15px var(--matrix-green-glow)";
      if (outcomeTitle) { outcomeTitle.textContent = "CRISIS CONTAINED - OBJECTIVE ACCOMPLISHED"; outcomeTitle.className = "h5 fw-bold mb-2 text-success"; }
      if (outcomeActions) outcomeActions.innerHTML = "";
      if (submitBtn) submitBtn.style.display = "none";
    } else if (kind === "incorrect") {
      if (statusBadge) { statusBadge.textContent = "COMPROMISED"; statusBadge.className = "badge bg-danger font-monospace"; }
      outcomeCard.className = "p-3 rounded border border-danger text-center font-monospace mt-3 tactical-card";
      if (outcomeTitle) { outcomeTitle.textContent = "BREACH OCCURRED - COUNTERMEASURE FAILED"; outcomeTitle.className = "h5 fw-bold mb-2 text-danger"; }
      if (submitBtn) submitBtn.style.display = "none";
      if (outcomeActions) {
        outcomeActions.innerHTML = allowRestart
          ? '<button type="button" class="btn btn-outline-warning font-monospace py-1 px-3 btn-sm restart-outcome-btn">Restart Incident</button>'
          : "";
        const rb = outcomeActions.querySelector(".restart-outcome-btn");
        if (rb) rb.addEventListener("click", restartScenario);
      }
    } else {
      if (statusBadge) { statusBadge.textContent = "CONCLUDED"; statusBadge.className = "badge bg-warning text-dark font-monospace"; }
      outcomeCard.className = "p-3 rounded border border-info text-center font-monospace mt-3 tactical-card";
      if (outcomeTitle) { outcomeTitle.textContent = "INCIDENT CONCLUDED - VERIFY YOUR RESPONSE"; outcomeTitle.className = "h5 fw-bold mb-2 text-info"; }
      if (outcomeActions) {
        outcomeActions.innerHTML = allowRestart
          ? '<button type="button" class="btn btn-outline-secondary font-monospace py-1 px-3 btn-sm restart-outcome-btn">Restart Incident</button>'
          : "";
        const rb = outcomeActions.querySelector(".restart-outcome-btn");
        if (rb) rb.addEventListener("click", restartScenario);
      }
      if (submitBtn) {
        submitBtn.style.display = isSolved ? "none" : "block";
        submitBtn.disabled = false;
      }
    }
    if (outcomeDesc && desc) outcomeDesc.textContent = desc;
  }

  function renderNode(node) {
    if (titleEl) titleEl.textContent = node.title || "Incident Decision";
    if (badgeEl) badgeEl.textContent = `STEP ${node.step || historyPath.length}`;

    if (consequenceBox && consequenceText) {
      if (node.consequence) {
        consequenceBox.style.display = "block";
        consequenceText.textContent = node.consequence;
      } else {
        consequenceBox.style.display = "none";
      }
    }

    if (mediaContainer && mediaElement) {
      let hasMedia = false;
      mediaElement.innerHTML = "";
      if (node.media_url) {
        hasMedia = true;
        const safeUrl = escapeHtml(node.media_url);
        if (node.media_type === "audio") {
          mediaElement.innerHTML = `
            <div class="d-flex align-items-center gap-2 mb-2">
              <span class="badge bg-danger font-monospace">AUDIO INTERCEPT</span>
              <audio controls class="w-100 mt-1" src="${safeUrl}"></audio>
            </div>`;
        } else {
          mediaElement.innerHTML = `<img src="${safeUrl}" alt="Incident Evidence" class="img-fluid rounded mb-2" style="max-height: 280px;">`;
        }
      }
      if (node.transcript && transcriptBox && transcriptText) {
        hasMedia = true;
        transcriptBox.style.display = "block";
        transcriptText.textContent = node.transcript;
      } else if (transcriptBox) {
        transcriptBox.style.display = "none";
      }
      mediaContainer.style.display = hasMedia ? "block" : "none";
    }

    if (textEl) textEl.textContent = node.text || "";

    if (node.is_ending) {
      if (actionsSection) actionsSection.style.display = "none";
      setOutcome("pending", node);
      return;
    }

    if (statusBadge) { statusBadge.textContent = "ACTIVE"; statusBadge.className = "badge bg-info font-monospace"; }
    if (outcomeCard) outcomeCard.style.display = "none";
    if (actionsSection) actionsSection.style.display = "block";
    if (submitBtn) submitBtn.style.display = "none";

    if (optionsContainer) {
      optionsContainer.innerHTML = "";
      (node.options || []).forEach((opt, idx) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "btn btn-outline-secondary text-start p-2 font-monospace d-flex align-items-center gap-2 tactical-card text-reset w-100 mb-2";
        btn.innerHTML = `
          <span class="badge bg-secondary font-monospace" style="font-size: 0.7rem;">#${idx + 1}</span>
          <span class="small flex-grow-1">${escapeHtml(opt.text)}</span>
          <span class="text-muted small">&rarr;</span>`;
        btn.addEventListener("click", () => {
          if (isSolved) return;
          go(historyPath.concat([opt.next]));
        });
        optionsContainer.appendChild(btn);
      });
    }
  }

  if (submitBtn) {
    submitBtn.addEventListener("click", () => {
      saveState();
      const alpineEl = document.querySelector("[x-data='Challenge']");
      const alpineData = alpineEl
        ? ((window.Alpine && typeof window.Alpine.$data === "function") ? window.Alpine.$data(alpineEl)
          : (alpineEl._x_dataStack ? alpineEl._x_dataStack[0] : (alpineEl.__x && alpineEl.__x.$data)))
        : null;
      if (alpineData && typeof alpineData.submitChallenge === "function") {
        alpineData.submission = chalInput ? chalInput.value : JSON.stringify({ path: historyPath });
        Promise.resolve(alpineData.submitChallenge()).then(() => {
          const status = alpineData.response && alpineData.response.data && alpineData.response.data.status;
          if (status === "correct" || status === "already_solved") setOutcome("correct");
          else if (status === "incorrect") setOutcome("incorrect");
        });
      }
    });
  }

  go(historyPath);
  return true;
}

CTFd._internal.challenge.postRender = initScenario;
window.addEventListener("ctfd:challenge-rendered", initScenario);

var scenarioRetryCount = 0;
var scenarioTimer = setInterval(function() {
  scenarioRetryCount++;
  if (initScenario() || scenarioRetryCount > 20) {
    clearInterval(scenarioTimer);
  }
}, 50);

CTFd._internal.challenge.submit = function(preview) {
  const challenge_id = parseInt(document.getElementById("challenge-id").value, 10);
  const submission = document.getElementById("challenge-input").value;
  const body = { challenge_id: challenge_id, submission: submission };
  const params = {};
  if (preview) {
    params["preview"] = true;
  }
  return CTFd.api.post_challenge_attempt(params, body).then(function(response) {
    return response;
  });
};
})();
