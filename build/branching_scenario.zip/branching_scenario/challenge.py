import json
from CTFd.models import Fails, Flags, Solves, db
from CTFd.plugins.challenges import BaseChallenge, ChallengeResponse
from CTFd.plugins.flags import get_flag_class
from CTFd.plugins.branching_scenario.models import BranchingScenarioChallenge, public_node_id
from CTFd.utils.user import get_current_user, get_current_team, is_admin


def get_default_sample_nodes():
    return {
        "start": {
            "title": "Incident Alert: Suspicious VIP Call",
            "text": "Your desk phone rings. An authoritative voice claiming to be the CFO states they are finalizing an emergency acquisition and need an immediate wire transfer override of $450,000.",
            "media_type": "audio",
            "media_url": "",
            "transcript": "Caller: 'Hello, this is Richard from Executive Finance. We need that offshore vendor authorization confirmed immediately or the contract defaults.'",
            "options": [
                {
                    "text": "Ask for urgent wire details and immediately process the override.",
                    "next_node": "bad_ending_wired",
                    "consequence": "You bypassed corporate multi-party authorization protocols."
                },
                {
                    "text": "Politely place caller on hold and initiate out-of-band verification via internal directory.",
                    "next_node": "investigate_call",
                    "consequence": "Standard operational security procedure: never trust inbound caller ID."
                }
            ]
        },
        "investigate_call": {
            "title": "Out-of-Band Channel Verification",
            "text": "You call the CFO's verified internal executive assistant. The assistant confirms the CFO is currently on an international flight with no connectivity and did not order any wire transfer.",
            "options": [
                {
                    "text": "Report the deepfake voice vishing incident to the SOC and log caller metadata.",
                    "next_node": "win",
                    "consequence": "Excellent response! SOC blocks the spoofed VoIP trunk and alerts the enterprise."
                },
                {
                    "text": "Ignore the call and resume regular work without notifying anyone.",
                    "next_node": "bad_ending_unreported",
                    "consequence": "The attacker proceeds to target another employee who falls for the pretext."
                }
            ]
        },
        "win": {
            "title": "Attack Neutralized: Enterprise Preserved",
            "text": "By following out-of-band verification and promptly notifying the SOC, you prevented a $450,000 fraud attempt. Threat intel identifies the campaign as advanced AI voice clone vishing.",
            "is_ending": True,
            "is_win": True
        },
        "bad_ending_wired": {
            "title": "Compromise: Fraud Succeeded",
            "text": "The funds were transferred to an untraceable offshore mule account. Internal Audit initiates a forensic inquiry.",
            "is_ending": True,
            "is_win": False
        },
        "bad_ending_unreported": {
            "title": "Secondary Compromise: Lateral Victim",
            "text": "Because the vishing campaign was not reported to the SOC, the attackers targeted a junior accountant 30 minutes later who approved the transfer.",
            "is_ending": True,
            "is_win": False
        }
    }


def parse_simple_scenario_text(text):
    nodes = {}
    current_node_id = None
    lines = (text or "").split("\n")
    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("[") and "]" in line:
            end_bracket = line.index("]")
            node_id = line[1:end_bracket].strip()
            title = line[end_bracket+1:].strip()
            current_node_id = node_id
            nodes[current_node_id] = {
                "title": title or node_id.replace("_", " ").title(),
                "text": "",
                "options": [],
                "is_ending": False,
                "is_win": "win" in node_id.lower()
            }
        elif current_node_id:
            if line.startswith(">"):
                choice_body = line[1:].strip()
                consequence = ""
                if "|" in choice_body:
                    parts = choice_body.split("|", 1)
                    choice_body = parts[0].strip()
                    consequence = parts[1].strip()
                target_node = ""
                choice_text = choice_body
                if "->" in choice_body:
                    cparts = choice_body.split("->", 1)
                    choice_text = cparts[0].strip()
                    target_node = cparts[1].strip()
                nodes[current_node_id]["options"].append({
                    "text": choice_text,
                    "next_node": target_node,
                    "consequence": consequence
                })
            else:
                if nodes[current_node_id]["text"]:
                    nodes[current_node_id]["text"] += " " + line
                else:
                    nodes[current_node_id]["text"] = line

    for nid, nd in nodes.items():
        if not nd.get("options"):
            nd["is_ending"] = True

    return nodes


def scenario_to_simple_text(nodes_json):
    try:
        nodes = json.loads(nodes_json or "{}")
        blocks = []
        for nid, nd in nodes.items():
            b = [f"[{nid}] {nd.get('title', '')}"]
            if nd.get("text"):
                b.append(nd.get("text", ""))
            for opt in nd.get("options", []):
                line = f"> {opt.get('text', '')} -> {opt.get('next_node', '')}"
                if opt.get("consequence"):
                    line += f" | {opt.get('consequence', '')}"
                b.append(line)
            blocks.append("\n".join(b))
        return "\n\n".join(blocks)
    except Exception:
        return ""


def public_to_real_map(c):
    return {public_node_id(c.id, nid): nid for nid in (c.nodes_data or {}).keys()}


def build_public_step(c, public_path):
    """Validate a path of public node ids and return only what the player may see now.
    Returns (payload, error_message)."""
    nodes = c.nodes_data or {}
    start_id = c.start_node_id or "start"
    if not public_path:
        public_path = [public_node_id(c.id, start_id)]
    real_by_pub = public_to_real_map(c)
    # Endings may point at undefined node ids; map those too so they can be reached.
    for node in nodes.values():
        for opt in node.get("options", []) or []:
            nxt = opt.get("next_node")
            if nxt:
                real_by_pub.setdefault(public_node_id(c.id, nxt), nxt)
    real_by_pub.setdefault(public_node_id(c.id, start_id), start_id)

    real_path = [real_by_pub.get(str(p)) for p in public_path]
    if any(r is None for r in real_path):
        return None, "Unknown scenario step."
    if real_path[0] != start_id:
        return None, "Path must begin at the scenario start."

    consequence = ""
    for i in range(len(real_path) - 1):
        from_node = nodes.get(real_path[i]) or {}
        match = [o for o in (from_node.get("options") or []) if o.get("next_node") == real_path[i + 1]]
        if not match:
            return None, "Illegal transition in scenario path."
        consequence = match[0].get("consequence") or ""

    node = nodes.get(real_path[-1]) or {}
    options = [
        {"text": o.get("text", ""), "next": public_node_id(c.id, o.get("next_node"))}
        for o in (node.get("options") or [])
        if o.get("next_node")
    ]
    payload = {
        "id": str(public_path[-1]),
        "step": len(real_path),
        "title": node.get("title") or "Incident Decision",
        "text": node.get("text") or "",
        "media_url": node.get("media_url") or "",
        "media_type": node.get("media_type") or "",
        "transcript": node.get("transcript") or "",
        "options": options,
        "consequence": consequence if c.show_feedback else "",
        "is_ending": len(options) == 0,
    }
    return payload, None


class BranchingScenarioChallengeType(BaseChallenge):
    id = "branching_scenario"
    name = "branching_scenario"
    templates = {
        "create": "/plugins/branching_scenario/assets/create.html",
        "update": "/plugins/branching_scenario/assets/update.html",
        "view": "/plugins/branching_scenario/assets/view.html",
    }
    scripts = {
        "create": "/plugins/branching_scenario/assets/create.js",
        "update": "/plugins/branching_scenario/assets/update.js",
        "view": "/plugins/branching_scenario/assets/view.js",
    }
    route = "/plugins/branching_scenario/assets/"
    challenge_model = BranchingScenarioChallenge

    @classmethod
    def read(cls, challenge):
        data = super().read(challenge)
        c = BranchingScenarioChallenge.query.filter_by(id=challenge.id).first()
        if not c:
            return data

        user = get_current_user()
        team = get_current_team()

        is_solved = False
        attempts_used = 0
        if user:
            filter_kwargs = {"challenge_id": c.id}
            if team:
                filter_kwargs["team_id"] = team.id
            else:
                filter_kwargs["user_id"] = user.id
            is_solved = Solves.query.filter_by(**filter_kwargs).count() > 0
            attempts_used = Fails.query.filter_by(**filter_kwargs).count()

        admin_view = is_admin()
        data.update({
            # CPQuest local fix: players get no graph or winning list; steps come from the step API
            "nodes_data": c.nodes_data if admin_view else {},
            "start_node_id": (c.start_node_id or "start") if admin_view else c.public_start_id,
            "winning_nodes": (c.winning_nodes or "win") if admin_view else "",
            "allow_restart": bool(c.allow_restart),
            "show_feedback": bool(c.show_feedback),
            "is_solved": is_solved,
            "attempts_used": attempts_used,
            "explanation": c.explanation if is_solved else "",
        })

        if is_admin():
            data["nodes_json"] = c.nodes_json
            data["scenario_text"] = scenario_to_simple_text(c.nodes_json)

        return data

    @classmethod
    def create(cls, request):
        challenge = super().create(request)
        data = request.form or request.get_json() or {}

        c = BranchingScenarioChallenge.query.filter_by(id=challenge.id).first()
        if c:
            c.start_node_id = (data.get("start_node_id") or "start").strip()
            c.winning_nodes = (data.get("winning_nodes") or "win").strip()
            c.allow_restart = str(data.get("allow_restart", "true")).lower() in ("true", "1", "yes", "on")
            c.show_feedback = str(data.get("show_feedback", "true")).lower() in ("true", "1", "yes", "on")
            c.explanation = data.get("explanation", "").strip()

            scenario_text = (data.get("scenario_text") or "").strip()
            nodes_json_val = (data.get("nodes_json") or "").strip()
            if scenario_text:
                parsed_nodes = parse_simple_scenario_text(scenario_text)
                c.nodes_json = json.dumps(parsed_nodes, indent=2)
            elif nodes_json_val:
                c.nodes_json = nodes_json_val
            else:
                c.nodes_json = json.dumps(get_default_sample_nodes(), indent=2)

            db.session.commit()

        return challenge

    @classmethod
    def update(cls, challenge, request):
        data = request.form or request.get_json() or {}

        for attr in ("start_node_id", "winning_nodes", "explanation"):
            if attr in data:
                setattr(challenge, attr, data[attr].strip())

        if "allow_restart" in data:
            challenge.allow_restart = str(data["allow_restart"]).lower() in ("true", "1", "yes", "on")

        if "show_feedback" in data:
            challenge.show_feedback = str(data["show_feedback"]).lower() in ("true", "1", "yes", "on")

        if "scenario_text" in data and data["scenario_text"].strip():
            parsed_nodes = parse_simple_scenario_text(data["scenario_text"])
            challenge.nodes_json = json.dumps(parsed_nodes, indent=2)
        elif "scenario_json" in data and data["scenario_json"].strip():
            challenge.nodes_json = data["scenario_json"].strip()
        elif "nodes_json" in data and data["nodes_json"].strip():
            challenge.nodes_json = data["nodes_json"].strip()

        return super().update(challenge, request)

    @classmethod
    def attempt(cls, challenge, request):
        data = request.form or request.get_json() or {}
        submission = (data.get("submission") or "").strip()

        c = BranchingScenarioChallenge.query.filter_by(id=challenge.id).first()
        if not c:
            return ChallengeResponse(status="incorrect", message="Challenge not found.")

        # Check standard Flags
        flags = Flags.query.filter_by(challenge_id=challenge.id).all()
        for flag in flags:
            try:
                flag_class = get_flag_class(flag.type)
                if flag_class.compare(flag, submission):
                    return ChallengeResponse(status="correct", message="Scenario Completed Successfully via Flag!")
            except Exception:
                pass

        # Submission expected:
        # JSON: {"node_id": "win", "path": ["start", "investigate_call", "win"]}
        # Or simple node string: "win"
        submitted_node = ""
        submitted_path = []

        try:
            if submission.startswith("{") and submission.endswith("}"):
                obj = json.loads(submission)
                submitted_node = obj.get("node_id") or obj.get("current_node") or ""
                submitted_path = obj.get("path") or []
            elif submission.startswith("[") and submission.endswith("]"):
                submitted_path = json.loads(submission)
                if submitted_path:
                    submitted_node = submitted_path[-1]
            elif "," in submission:
                submitted_path = [s.strip() for s in submission.split(",") if s.strip()]
                if submitted_path:
                    submitted_node = submitted_path[-1]
            else:
                submitted_node = submission
        except Exception:
            return ChallengeResponse(status="incorrect", message="Invalid scenario submission format.")

        winning_set = set([w.strip().lower() for w in (c.winning_nodes or "win").split(",") if w.strip()])
        nodes = c.nodes_data

        # CPQuest local fix: players submit opaque public node ids; translate them back
        real_by_pub = public_to_real_map(c)
        for node in (nodes or {}).values():
            for opt in node.get("options", []) or []:
                if opt.get("next_node"):
                    real_by_pub.setdefault(public_node_id(c.id, opt["next_node"]), opt["next_node"])
        # only opaque ids are accepted, so guessed internal ids (e.g. "start" -> "win") are rejected
        submitted_path = [real_by_pub.get(str(p)) for p in (submitted_path or [])]
        if any(p is None for p in submitted_path):
            return ChallengeResponse(status="incorrect", message="Invalid scenario path. Restart the incident and try again.")
        submitted_node = real_by_pub.get(str(submitted_node), "") if submitted_node else ""

        # Enforce that if scenario nodes are defined, a valid path from start_node_id must be traversed
        if nodes:
            start_id = c.start_node_id or "start"
            if not submitted_path:
                # If only submitted_node was provided without path, allow only if start_node is already a winning node
                if submitted_node and submitted_node.lower() in winning_set and start_id.lower() in winning_set:
                    submitted_path = [start_id]
                else:
                    return ChallengeResponse(
                        status="incorrect",
                        message="A verified decision path from the incident start is required to resolve the crisis."
                    )

            if submitted_path[0] != start_id:
                return ChallengeResponse(
                    status="incorrect",
                    message="Path must begin at the designated starting scenario node."
                )

            for i in range(len(submitted_path) - 1):
                from_node = nodes.get(submitted_path[i])
                to_node_id = submitted_path[i + 1]
                if not from_node:
                    return ChallengeResponse(status="incorrect", message="Invalid scenario path. Restart the incident and try again.")
                valid_nexts = [opt.get("next_node") for opt in from_node.get("options", [])]
                if to_node_id not in valid_nexts:
                    return ChallengeResponse(status="incorrect", message="Invalid scenario path. Restart the incident and try again.")

            submitted_node = submitted_path[-1]

        if not submitted_node:
            return ChallengeResponse(status="incorrect", message="No final decision node reached.")

        if submitted_node.lower() in winning_set:
            return ChallengeResponse(
                status="correct",
                message="Scenario Completed Successfully! Crisis averted and threat eradicated."
            )
        else:
            return ChallengeResponse(
                status="incorrect",
                message="Incident outcome was sub-optimal. Restart and select safer countermeasures."
            )
