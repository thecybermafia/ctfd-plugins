import json
from CTFd.models import Challenges, db


class QuizChallenge(Challenges):
    __mapper_args__ = {"polymorphic_identity": "quiz"}
    id = db.Column(
        db.Integer, db.ForeignKey("challenges.id", ondelete="CASCADE"), primary_key=True
    )
    question_mode = db.Column(db.String(32), default="single")  # single | multiple
    options_json = db.Column(db.Text, default="[]")
    randomize_options = db.Column(db.Boolean, default=True)
    max_attempts = db.Column(db.Integer, default=0)  # 0 for unlimited
    penalty_per_attempt = db.Column(db.Integer, default=0)
    explanation = db.Column(db.Text, default="")
    partial_scoring = db.Column(db.Boolean, default=False)

    def __init__(self, *args, **kwargs):
        self.question_mode = kwargs.pop("question_mode", "single")
        self.options_json = kwargs.pop("options_json", "[]")
        self.randomize_options = kwargs.pop("randomize_options", True)
        if isinstance(self.randomize_options, str):
            self.randomize_options = self.randomize_options.lower() in ("true", "1", "yes")
        self.max_attempts = int(kwargs.pop("max_attempts", 0) or 0)
        self.penalty_per_attempt = int(kwargs.pop("penalty_per_attempt", 0) or 0)
        self.explanation = kwargs.pop("explanation", "")
        self.partial_scoring = kwargs.pop("partial_scoring", False)
        if isinstance(self.partial_scoring, str):
            self.partial_scoring = self.partial_scoring.lower() in ("true", "1", "yes")
        kwargs.pop("options_text", None)
        super(QuizChallenge, self).__init__(**kwargs)

    @property
    def options_data(self):
        try:
            raw = json.loads(self.options_json or "[]")
            if isinstance(raw, dict):
                raw = list(raw.values())
            if not isinstance(raw, list):
                raw = [str(self.options_json)]

            normalized = []
            for idx, item in enumerate(raw):
                if isinstance(item, dict):
                    opt_id = str(item.get("id") or f"opt_{idx}")
                    opt_text = str(item.get("text", "")).strip()
                    is_correct = bool(item.get("correct", False))
                    normalized.append({
                        "id": opt_id,
                        "text": opt_text,
                        "correct": is_correct
                    })
                elif isinstance(item, (str, int, float, bool)):
                    clean = str(item).strip()
                    is_correct = clean.startswith("*") or clean.lower().startswith("[x]")
                    if clean.startswith("*"):
                        clean = clean.lstrip("*").strip()
                    elif clean.lower().startswith("[x]"):
                        clean = clean[3:].strip()
                    elif clean.startswith("[ ]"):
                        clean = clean[3:].strip()
                    normalized.append({
                        "id": f"opt_{idx}",
                        "text": clean,
                        "correct": is_correct
                    })
            return normalized
        except Exception:
            return []

    @property
    def options_text(self):
        try:
            opts = self.options_data
            lines = []
            for o in opts:
                prefix = "* " if o.get("correct") else ""
                lines.append(f"{prefix}{o.get('text', '')}")
            return "\n".join(lines)
        except Exception:
            return ""

    # CPQuest local fix: the view template receives this model (not read()), so expose the
    # options exactly as read() sends them to players: no 'correct' flag, and shuffled per
    # player (same seed as read()) when randomize_options is enabled.
    @property
    def participant_options(self):
        from CTFd.plugins.quiz_challenges.challenge import get_deterministic_shuffle
        from CTFd.utils.user import get_current_team, get_current_user

        options = self.get_sanitized_options()
        if self.randomize_options:
            user = get_current_user()
            team = get_current_team()
            seed = f"{team.id if team else (user.id if user else 0)}_{self.id}"
            options = get_deterministic_shuffle(options, seed)
        return options

    def get_sanitized_options(self):
        """Returns options list for players without the 'correct' flag."""
        opts = self.options_data
        sanitized = []
        for opt in opts:
            sanitized.append({
                "id": opt.get("id"),
                "text": opt.get("text", "")
            })
        return sanitized

    # CPQuest local fix: the admin create/update forms post these display-only fields and
    # CTFd assigns every posted field onto the model. Without a setter that raised
    # AttributeError and the save failed; the plugin already parses the text itself.
    @options_text.setter
    def options_text(self, value):
        pass

