import json
from CTFd.models import Challenges, db


class UrlAnatomyChallenge(Challenges):
    __mapper_args__ = {"polymorphic_identity": "url_anatomy"}
    id = db.Column(
        db.Integer, db.ForeignKey("challenges.id", ondelete="CASCADE"), primary_key=True
    )
    urls_json = db.Column(db.Text, default="[]")
    enable_qr_code = db.Column(db.Boolean, default=False)
    allow_punycode_toggle = db.Column(db.Boolean, default=True)
    explanation = db.Column(db.Text, default="")

    def __init__(self, *args, **kwargs):
        self.urls_json = kwargs.pop("urls_json", "[]")
        self.enable_qr_code = kwargs.pop("enable_qr_code", False)
        if isinstance(self.enable_qr_code, str):
            self.enable_qr_code = self.enable_qr_code.lower() in ("true", "1", "yes", "on")
        self.allow_punycode_toggle = kwargs.pop("allow_punycode_toggle", True)
        if isinstance(self.allow_punycode_toggle, str):
            self.allow_punycode_toggle = self.allow_punycode_toggle.lower() in ("true", "1", "yes", "on")
        self.explanation = kwargs.pop("explanation", "")
        # CPQuest local fix: urls_text is a read-only property (create() parses it); passing it
        # through to the model raised AttributeError and every create from the admin form failed.
        kwargs.pop("urls_text", None)
        super(UrlAnatomyChallenge, self).__init__(**kwargs)

    def qr_svg(self, url):
        """CPQuest local fix: "Enable QR code" was stored but never rendered."""
        from CTFd.plugins.url_anatomy.qr import to_svg

        try:
            return to_svg(url or "")
        except Exception:
            return ""

    @property
    def urls_data(self):
        try:
            return json.loads(self.urls_json or "[]")
        except Exception:
            return []

    @property
    def urls_text(self):
        try:
            urls = json.loads(self.urls_json or "[]")
            lines = []
            for u in urls:
                lines.append(f"{u.get('raw_url', '')} | {u.get('question', '')} | {u.get('correct_token', '')} | {u.get('explanation', '')}")
            return "\n".join(lines)
        except Exception:
            return ""

    # CPQuest local fix: the admin create/update forms post these display-only fields and
    # CTFd assigns every posted field onto the model. Without a setter that raised
    # AttributeError and the save failed; the plugin already parses the text itself.
    @urls_text.setter
    def urls_text(self, value):
        pass

