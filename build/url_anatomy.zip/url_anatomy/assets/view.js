(function() {
CTFd._internal.challenge.data = undefined;
CTFd._internal.challenge.renderer = null;
CTFd._internal.challenge.preRender = function() {};
CTFd._internal.challenge.render = null;

function initUrlAnatomy() {
  const chalIdEl = document.getElementById("challenge-id");
  const container = document.querySelector(".url-anatomy-container");
  if (!chalIdEl || !container) return false;

  const challengeId = chalIdEl.value;
  const configJsonEl = document.getElementById("url-anatomy-config-json");
  const chalInput = document.getElementById("challenge-input");
  const answeredCountEl = document.getElementById("url-answered-count");
  const submitBtn = document.getElementById("challenge-submit");

  let config = {};
  if (configJsonEl && configJsonEl.textContent) {
    try {
      config = JSON.parse(configJsonEl.textContent);
    } catch (e) {
      console.error("Failed to parse url_anatomy config JSON:", e);
    }
  }

  if (Object.keys(config).length === 0 && CTFd._internal.challenge.data) {
    config = CTFd._internal.challenge.data;
  }

  const urls = config.urls_data || [];
  const isSolved = Boolean(config.is_solved);
  const storageKey = `ctfd_url_anatomy_${challengeId}`;

  let userSelections = {};
  try {
    userSelections = JSON.parse(localStorage.getItem(storageKey) || "{}");
  } catch (e) {
    userSelections = {};
  }

  function updateSelectionsUI() {
    let answered = 0;
    urls.forEach((u) => {
      const selected = userSelections[u.id];
      const previewEl = document.querySelector(`.selected-segment-preview[data-url-id="${u.id}"]`);
      const statusBadge = document.querySelector(`.token-status-badge[data-url-id="${u.id}"]`);
      const buttons = document.querySelectorAll(`.url-token-btn[data-url-id="${u.id}"]`);

      if (selected) {
        answered++;
        if (previewEl) previewEl.textContent = selected;
        if (statusBadge) {
          statusBadge.textContent = "SELECTED";
          statusBadge.className = "badge bg-success token-status-badge font-monospace";
        }
      } else {
        if (previewEl) previewEl.textContent = "None (Click a segment above)";
        if (statusBadge) {
          statusBadge.textContent = "WAITING FOR SELECTION";
          statusBadge.className = "badge bg-secondary token-status-badge font-monospace";
        }
      }

      buttons.forEach((btn) => {
        const val = btn.getAttribute("data-token-value");
        const puny = btn.getAttribute("data-token-punycode");
        const isMatched = selected && (selected === val || (puny && selected === puny));
        if (isMatched) {
          btn.classList.add("url-token-active");
          btn.classList.remove("btn-outline-secondary");
        } else {
          btn.classList.remove("url-token-active");
          btn.classList.add("btn-outline-secondary");
        }
      });
    });

    if (answeredCountEl) {
      answeredCountEl.textContent = answered;
    }

    if (chalInput) {
      chalInput.value = JSON.stringify(userSelections);
      chalInput.dispatchEvent(new Event("input", { bubbles: true }));
    }

    if (submitBtn) {
      submitBtn.disabled = !(urls.length > 0 && answered >= urls.length);
    }
  }

  // Token click handlers
  document.querySelectorAll(".url-token-btn").forEach((btn) => {
    if (btn.dataset.urlBound) return;
    btn.dataset.urlBound = "true";
    btn.addEventListener("click", () => {
      if (isSolved) return;
      const urlId = btn.getAttribute("data-url-id");
      const tokenVal = btn.getAttribute("data-token-value");
      if (!urlId || !tokenVal) return;

      userSelections[urlId] = tokenVal;
      try {
        localStorage.setItem(storageKey, JSON.stringify(userSelections));
      } catch (e) {}

      updateSelectionsUI();
    });
  });

  // Punycode toggle handlers
  document.querySelectorAll(".punycode-toggle-btn").forEach((toggleBtn) => {
    if (toggleBtn.dataset.urlBound) return;
    toggleBtn.dataset.urlBound = "true";
    let showRaw = false;
    toggleBtn.addEventListener("click", () => {
      showRaw = !showRaw;
      const urlId = toggleBtn.getAttribute("data-url-id");
      toggleBtn.textContent = showRaw ? "Show Unicode (Rendered)" : "Show Punycode (Raw)";

      document.querySelectorAll(`.url-token-btn[data-url-id="${urlId}"]`).forEach((btn) => {
        const puny = btn.getAttribute("data-token-punycode");
        const val = btn.getAttribute("data-token-value");
        const textSpan = btn.querySelector(".token-text");
        if (puny && textSpan) {
          textSpan.textContent = showRaw ? puny : val;
        }
      });
    });
  });

  // Challenge submit button handler
  if (submitBtn && !submitBtn.dataset.urlBound) {
    submitBtn.dataset.urlBound = "true";
    submitBtn.addEventListener("click", () => {
      if (chalInput) {
        chalInput.value = JSON.stringify(userSelections);
        chalInput.dispatchEvent(new Event("input", { bubbles: true }));
      }
      const alpineEl = document.querySelector("[x-data='Challenge']");
      // CPQuest local fix: the theme runs Alpine v3, which has no __x; the old v2-only lookup
      // meant this submit button silently did nothing. Resolve the component for v3 or v2.
      const alpineData = alpineEl
        ? ((window.Alpine && typeof window.Alpine.$data === "function") ? window.Alpine.$data(alpineEl)
          : (alpineEl._x_dataStack ? alpineEl._x_dataStack[0] : (alpineEl.__x && alpineEl.__x.$data)))
        : null;
      if (alpineData && typeof alpineData.submitChallenge === "function") {
        alpineData.submission = chalInput ? chalInput.value : JSON.stringify(userSelections);
        alpineData.submitChallenge();
      }
    });
  }

  updateSelectionsUI();
  return true;
}

CTFd._internal.challenge.postRender = initUrlAnatomy;
window.addEventListener("ctfd:challenge-rendered", initUrlAnatomy);

var urlAnatomyRetry = 0;
var urlAnatomyTimer = setInterval(function() {
  urlAnatomyRetry++;
  if (initUrlAnatomy() || urlAnatomyRetry > 20) {
    clearInterval(urlAnatomyTimer);
  }
}, 50);

CTFd._internal.challenge.submit = function(preview) {
  const challenge_id = parseInt(document.getElementById("challenge-id").value, 10);
  const submission = document.getElementById("challenge-input").value;

  const body = {
    challenge_id: challenge_id,
    submission: submission
  };
  const params = {};
  if (preview) {
    params["preview"] = true;
  }

  return CTFd.api.post_challenge_attempt(params, body).then(function(response) {
    return response;
  });
};
})();
