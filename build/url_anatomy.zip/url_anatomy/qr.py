"""Minimal QR Code encoder (byte mode, error correction level M, versions 1-10) rendering SVG.

CPQuest local addition for the url_anatomy "Enable QR code" option, which was stored but never
rendered. Follows ISO/IEC 18004 (same structure as Project Nayuki's reference generator).
"""

# Error correction level M only: format bits value 0b00
_ECL_M_FORMAT = 0
# Per version (index 1..10): EC codewords per block and number of blocks, level M
_ECC_PER_BLOCK_M = (None, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26)
_NUM_BLOCKS_M = (None, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5)
MAX_VERSION = 10


def _num_raw_data_modules(ver):
    result = (16 * ver + 128) * ver + 64
    if ver >= 2:
        numalign = ver // 7 + 2
        result -= (25 * numalign - 10) * numalign - 55
        if ver >= 7:
            result -= 36
    return result


def _num_data_codewords(ver):
    return _num_raw_data_modules(ver) // 8 - _ECC_PER_BLOCK_M[ver] * _NUM_BLOCKS_M[ver]


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _alignment_positions(ver, size):
    if ver == 1:
        return []
    numalign = ver // 7 + 2
    step = (ver * 8 + numalign * 3 + 5) // (numalign * 4 - 4) * 2
    result = [size - 7 - i * step for i in range(numalign - 1)] + [6]
    return list(reversed(result))


def encode(text):
    """Return a square boolean matrix (list of rows) for text, or None if too long."""
    data = text.encode("utf-8")
    ver = None
    for v in range(1, MAX_VERSION + 1):
        cc_bits = 8 if v <= 9 else 16
        if 4 + cc_bits + 8 * len(data) <= _num_data_codewords(v) * 8 and len(data) < (1 << cc_bits):
            ver = v
            break
    if ver is None:
        return None

    # --- data bit stream ---
    bits = []

    def append(val, n):
        for i in reversed(range(n)):
            bits.append((val >> i) & 1)

    append(0b0100, 4)
    append(len(data), 8 if ver <= 9 else 16)
    for b in data:
        append(b, 8)
    capacity = _num_data_codewords(ver) * 8
    append(0, min(4, capacity - len(bits)))
    append(0, (-len(bits)) % 8)
    pad = 0xEC
    while len(bits) < capacity:
        append(pad, 8)
        pad ^= 0xEC ^ 0x11
    codewords = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]

    # --- error correction and interleaving ---
    numblocks = _NUM_BLOCKS_M[ver]
    blockecclen = _ECC_PER_BLOCK_M[ver]
    rawcodewords = _num_raw_data_modules(ver) // 8
    numshortblocks = numblocks - rawcodewords % numblocks
    shortblocklen = rawcodewords // numblocks
    divisor = _rs_divisor(blockecclen)
    blocks = []
    k = 0
    for i in range(numblocks):
        datlen = shortblocklen - blockecclen + (0 if i < numshortblocks else 1)
        dat = codewords[k:k + datlen]
        k += datlen
        ecc = _rs_remainder(dat, divisor)
        if i < numshortblocks:
            dat = dat + [0]
        blocks.append(dat + ecc)
    final = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if i != shortblocklen - blockecclen or j >= numshortblocks:
                final.append(blk[i])
    assert len(final) == rawcodewords

    # --- function patterns ---
    size = ver * 4 + 17
    modules = [[False] * size for _ in range(size)]
    isfunc = [[False] * size for _ in range(size)]

    def setf(x, y, dark):
        modules[y][x] = dark
        isfunc[y][x] = True

    for i in range(size):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)

    def finder(cx, cy):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    dist = max(abs(dx), abs(dy))
                    setf(x, y, dist not in (2, 4))

    finder(3, 3)
    finder(size - 4, 3)
    finder(3, size - 4)

    pos = _alignment_positions(ver, size)
    n = len(pos)
    for i in range(n):
        for j in range(n):
            if (i == 0 and j == 0) or (i == 0 and j == n - 1) or (i == n - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(pos[i] + dx, pos[j] + dy, max(abs(dx), abs(dy)) != 1)

    def draw_format(mask):
        data5 = _ECL_M_FORMAT << 3 | mask
        rem = data5
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        fbits = (data5 << 10 | rem) ^ 0x5412
        bit = lambda i: (fbits >> i) & 1 != 0
        for i in range(0, 6):
            setf(8, i, bit(i))
        setf(8, 7, bit(6))
        setf(8, 8, bit(7))
        setf(7, 8, bit(8))
        for i in range(9, 15):
            setf(14 - i, 8, bit(i))
        for i in range(0, 8):
            setf(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, bit(i))
        setf(8, size - 8, True)

    draw_format(0)  # reserve format areas

    if ver >= 7:
        rem = ver
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        vbits = ver << 12 | rem
        for i in range(18):
            b = (vbits >> i) & 1 != 0
            a, c = size - 11 + i % 3, i // 3
            setf(a, c, b)
            setf(c, a, b)

    # --- place codewords (zigzag) ---
    i = 0
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not isfunc[y][x] and i < len(final) * 8:
                    modules[y][x] = ((final[i >> 3] >> (7 - (i & 7))) & 1) != 0
                    i += 1
        right -= 2

    masks = [
        lambda x, y: (x + y) % 2 == 0,
        lambda x, y: y % 2 == 0,
        lambda x, y: x % 3 == 0,
        lambda x, y: (x + y) % 3 == 0,
        lambda x, y: (x // 3 + y // 2) % 2 == 0,
        lambda x, y: x * y % 2 + x * y % 3 == 0,
        lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
        lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
    ]

    def apply_mask(m):
        f = masks[m]
        for y in range(size):
            for x in range(size):
                if not isfunc[y][x] and f(x, y):
                    modules[y][x] = not modules[y][x]

    def penalty():
        score = 0
        for grid in (modules, [list(col) for col in zip(*modules)]):
            for row in grid:
                run, prev = 0, None
                for v in row:
                    if v == prev:
                        run += 1
                    else:
                        if run >= 5:
                            score += 3 + run - 5
                        run, prev = 1, v
                if run >= 5:
                    score += 3 + run - 5
                s = "".join("1" if v else "0" for v in row)
                score += 40 * (s.count("10111010000") + s.count("00001011101"))
        for y in range(size - 1):
            for x in range(size - 1):
                c = modules[y][x]
                if c == modules[y][x + 1] == modules[y + 1][x] == modules[y + 1][x + 1]:
                    score += 3
        dark = sum(v for row in modules for v in row)
        total = size * size
        k5 = abs(dark * 20 - total * 10) // total
        score += k5 * 10
        return score

    best, best_score = 0, None
    for m in range(8):
        apply_mask(m)
        draw_format(m)
        sc = penalty()
        if best_score is None or sc < best_score:
            best, best_score = m, sc
        apply_mask(m)  # undo (XOR)
    apply_mask(best)
    draw_format(best)
    return modules


def to_svg(text, module_px=4, border=4, dark="#000000", light="#ffffff"):
    matrix = encode(text)
    if matrix is None:
        return ""
    size = len(matrix)
    dim = size + border * 2
    parts = []
    for y, row in enumerate(matrix):
        for x, v in enumerate(row):
            if v:
                parts.append(f"M{x + border},{y + border}h1v1h-1z")
    px = dim * module_px
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {dim} {dim}" width="{px}" height="{px}" '
        f'shape-rendering="crispEdges" role="img" aria-label="QR code">'
        f'<rect width="100%" height="100%" fill="{light}"/><path d="{" ".join(parts)}" fill="{dark}"/></svg>'
    )
