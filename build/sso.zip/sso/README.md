# 🔐 CTFd Enterprise Single Sign-On (SSO) Plugin

A robust, enterprise-grade Single Sign-On (SSO) and identity federation plugin for [CTFd](https://ctfd.io/). Supports major OAuth2, OpenID Connect (OIDC), and SAML 2.0 identity providers with mandatory SSO policy enforcement, auto-provisioning, and automated registration visibility synchronization.

---

## ✨ Features

- **Multi-Provider Identity Federation**:
  - **Disable SSO**: Standard CTFd local credential authentication.
  - **SAML 2.0**: Enterprise identity providers (Okta SAML, Shibboleth, Active Directory ADFS, OneLogin).
  - **Discord**: OAuth2 integration with Discord guilds and accounts.
  - **GitHub**: OAuth2 authentication via GitHub accounts or enterprise organizations.
  - **Google**: OAuth2 / OpenID Connect federation via Google Workspace or consumer accounts.
  - **Azure (Microsoft Entra ID)**: Enterprise directory authentication via Microsoft Azure tenants.
  - **Okta**: OAuth2 / OIDC authentication via custom Okta domains.
- **Granular User Enforcement Policies**:
  - **All Users**: Mandatory SSO for all participants and administrators. Local password logins are blocked.
  - **Admins Only**: Enforces SSO specifically for privileged administrator accounts while leaving standard competitor logins flexible.
- **Automated Registration Visibility Sync**:
  - Setting User Settings to **All Users** automatically synchronizes CTFd's **Registration Visibility** to **Private** to prevent unauthorized public account creation bypassing corporate identity vetting.
  - Interactive warning banner in the Admin Console alerting administrators if registration is public when SSO is required.
- **Fail-Safe Disaster Recovery**:
  - Built-in emergency administrative bypass query (`/login?emergency_auth=true`) allowing authorized administrators with root database/console access to log in with emergency local credentials in case of third-party IdP outages.
- **Official CTFd Fallback URL & Admin Bypass Support**:
  - Compliant with [CTFd Official SSO Documentation](https://docs.ctfd.io/docs/settings/single-sign-on/#fallback-url).
  - When any Single Sign On configuration is enabled, users with local CTFd accounts may still login by browsing directly to `https://[ctfd]/admin` or `https://[ctfd]/login?fallback=1`.
- **Automated User Provisioning**:
  - Automatically provisions verified CTFd user profiles upon successful identity assertion, extracting name, email, and authentication tokens.

---

## 🔗 Fallback URL & Local Accounts

When any Single Sign-On configuration is enabled:
- **Direct Login Redirection**: Visiting `https://[ctfd]/login` directly redirects the user immediately to the configured SSO provider.
- **Local Account Fallback**: Users with local CTFd accounts (or administrators during IdP network disruptions) can log in by visiting:
  ```text
  https://[ctfd]/login?fallback=1
  ```
- **Admin Panel Access**: Unauthenticated users navigating directly to `https://[ctfd]/admin` are automatically routed to the local fallback login prompt (`/login?fallback=1&next=/admin`), ensuring emergency administrator access is never severed.

## 🛠️ Configuration & Usage

### 1. Modern Admin Console Setup (`/admin/sso`)
1. Log into your CTFd instance as an administrator.
2. In the Admin Panel navbar, click **Single Sign-On** (`/admin/sso`).
3. The newly redesigned, intuitive tabbed console provides dedicated configuration panes for:
   - **General Settings**: Choose the active SSO provider, User Settings enforcement policy (`All Users` vs `Admins Only`), and Registration Visibility (`Public` vs `Private`).
   - **SAML**:
     - *Identity Provider (IdP)*: SAML IdP Metadata URL or SAML IdP Metadata XML.
     - *Service Provider (SP)*: SAML SP URL, SAML Login URL, and SAML SP Metadata XML.
   - **Discord**:
     - Pre-configured Callback URL (`/oauth/discord/authorized`) with one-click copy.
     - Client ID, Client Secret, and configurable Scopes (`identify email`).
   - **GitHub & GitHub Enterprise**:
     - Pre-configured Callback URL (`/oauth/github/authorized`) with one-click copy.
     - Client ID, Client Secret, and Scopes (`user:email`).
     - GitHub Enterprise Server overrides: Base API URL, Custom Authorization URL, Custom Token URL.
   - **Google Workspace**:
     - Pre-configured Callback URL (`/oauth/google/authorized`) with one-click copy.
     - Client ID, Client Secret, and Scopes (`openid email profile`).
     - Hosted Domain restriction (`hd` parameter, e.g. `example.com` or `university.edu`).
   - **Microsoft Azure / Entra ID**:
     - Pre-configured Callback URL (`/oauth/azure/authorized`) with one-click copy.
     - Application (Client) ID, Client Secret, Directory (Tenant) ID (`common`, `organizations`, or UUID), and Scopes.
   - **Okta**:
     - Pre-configured Callback URL (`/oauth/okta/authorized`) with one-click copy.
     - Client ID, Client Secret, and Okta Organization Base URL (`https://example.okta.com`).
     - Scopes and Advanced Authorization / Token endpoint overrides.
4. Click **Save SSO Configuration** on the bottom sticky action bar.

---

## 🔒 Defensive Security Architecture

1. **State & CSRF Token Validation**:
   - OAuth flows generate and verify cryptographic `state` parameters stored in the session to prevent login CSRF attacks.
2. **Strict Redirection Whitelist**:
   - Post-authentication redirects validate host boundaries to eliminate Open Redirect vulnerabilities.
3. **Registration Policy Lockout Defense**:
   - Synchronizes `registration_visibility = "private"` when SSO is mandatory for all users, closing race conditions where adversaries register unmanaged local accounts.
4. **Emergency Disaster Recovery Channel**:
   - The emergency bypass parameter (`?emergency_auth=true`) requires valid admin credentials and does not weaken standard authentication checks.

---

## 📜 Attribution

Part of the **CTFd Plugins Suite by CyberMafia** ([https://github.com/thecybermafia/ctfd-plugins](https://github.com/thecybermafia/ctfd-plugins)). Licensed under Apache 2.0 with mandatory attribution.
